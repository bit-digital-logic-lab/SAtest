`timescale 1ns/1ps
// 32位回绕加法逐拍验证：定向边界 + 随机；检查输入寄存器/输出寄存器两级延迟。
module tb_add32;
    logic clk=0, rst_n=0;
    logic [31:0] a=0, b=0;
    wire  [31:0] sum;

    adder150_wrap32 dut(.clk(clk),.rst_n(rst_n),.a(a),.b(b),.sum(sum));

    always #3.333333 clk = ~clk; // 约150MHz，仅用于功能逐拍验证

    integer errors=0, checks=0, cyc, seed=32'h1357_2468;
    logic [31:0] a_q_m=0, b_q_m=0, sum_m=0;
    logic [31:0] na, nb;

    task automatic check_now;
        begin
            checks = checks + 1; // 每拍检查一次输出寄存器
            if (sum !== sum_m) begin
                errors = errors + 1;
                if (errors <= 10)
                    $display("ADD32_MISMATCH cyc=%0d got=%08x exp=%08x", cyc, sum, sum_m);
            end
        end
    endtask

    initial begin
        // 复位保持三拍，确保输入/输出寄存器清零。
        repeat (3) @(negedge clk);
        rst_n = 1;
        @(negedge clk);

        // 定向边界：回绕、最大/最小、进位链全1、交替位。
        for (cyc=0; cyc<16; cyc=cyc+1) begin
            case (cyc)
                0: begin na=32'h0000_0000; nb=32'h0000_0000; end
                1: begin na=32'hFFFF_FFFF; nb=32'h0000_0001; end
                2: begin na=32'hFFFF_FFFF; nb=32'hFFFF_FFFF; end
                3: begin na=32'h7FFF_FFFF; nb=32'h0000_0001; end
                4: begin na=32'h8000_0000; nb=32'h8000_0000; end
                5: begin na=32'h7FFF_FFFF; nb=32'h7FFF_FFFF; end
                6: begin na=32'h5555_5555; nb=32'hAAAA_AAAA; end
                7: begin na=32'hAAAA_AAAA; nb=32'h5555_5555; end
                8: begin na=32'h0000_FFFF; nb=32'h0000_0001; end
                9: begin na=32'hFFFF_FF00; nb=32'h0000_0100; end
                10: begin na=32'h1234_5678; nb=32'h8765_4321; end
                11: begin na=32'hDEAD_BEEF; nb=32'h0000_0001; end
                12: begin na=32'h0000_0001; nb=32'hFFFF_FFFE; end
                13: begin na=32'hFFFF_FFFE; nb=32'h0000_0002; end
                14: begin na=32'h8000_0001; nb=32'h7FFF_FFFF; end
                default: begin na=32'hFFFF_0000; nb=32'h0000_FFFF; end
            endcase
            check_now();
            sum_m = a_q_m + b_q_m; // 模型：输出寄存器采样上一拍输入寄存器之和
            a_q_m = na; b_q_m = nb;
            a = na; b = nb;
            @(negedge clk);
        end

        // 随机逐拍：每拍都检查，覆盖全32位进位链和回绕。
        for (cyc=0; cyc<20000; cyc=cyc+1) begin
            check_now();
            na = $random(seed);
            nb = $random(seed);
            // 周期性插入极端值，避免随机数长时间避开进位边界。
            if ((cyc % 257) == 0) begin na = 32'hFFFF_FFFF; nb = $random(seed); end
            if ((cyc % 389) == 0) begin na = 32'h8000_0000; nb = 32'h8000_0000; end
            if ((cyc % 521) == 0) begin na = 32'h7FFF_FFFF; nb = 32'h7FFF_FFFF; end
            sum_m = a_q_m + b_q_m;
            a_q_m = na; b_q_m = nb;
            a = na; b = nb;
            @(negedge clk);
        end

        // 冲刷两级寄存器，确认最后结果仍逐拍正确。
        repeat (3) begin
            check_now();
            sum_m = a_q_m + b_q_m;
            a_q_m = 0; b_q_m = 0;
            a = 0; b = 0;
            @(negedge clk);
        end

        $display("TB_ADD32_RESULT checks=%0d errors=%0d", checks, errors);
        if (errors != 0) $fatal(1, "TB_ADD32 FAIL");
        $display("TB_ADD32 PASS");
        $finish;
    end
endmodule
