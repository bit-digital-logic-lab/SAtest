`timescale 1ns/1ps
// 4×4行加法集成逐拍验证（不含乘法器）：
// 16个原kwt_csa32寄存器、4选1行MUX、4个32位加法、finalize写回。
// 参考模型与RTL同拍更新，覆盖load/finalize/valid优先级和随机行切换。
module tb_row_core;
    logic clk=0, rst_n=0;
    logic valid=0, load=0, row_issue=0;
    logic [1:0] row_select=0;
    logic [16*22-1:0] product='0;
    wire [16*32-1:0] sum_o, carry_o;

    adder150_row_core dut(.clk(clk),.rst_n(rst_n),.product(product),
        .valid(valid),.load(load),.row_issue(row_issue),.row_select(row_select),
        .sum_o(sum_o),.carry_o(carry_o));

    always #3.333333 clk = ~clk; // 功能验证时钟，不参与综合STA

    logic [31:0] m_sum[0:15];   // 参考模型的16个sum
    logic [31:0] m_carry[0:15]; // 参考模型的16个carry
    logic [31:0] old_sum, old_carry, p32;
    integer errors=0, pe_checks=0, cycles=0, i, cyc;
    integer seed=32'h0BAD_F00D;
    integer issue_gap=3;
    integer load_gap=700;

    task automatic check_all;
        begin
            for (i=0;i<16;i=i+1) begin
                pe_checks = pe_checks + 2; // sum和carry各检查一次
                if (sum_o[i*32+:32] !== m_sum[i]) begin
                    errors = errors + 1;
                    if (errors <= 10)
                        $display("ROW_CORE_SUM_MISMATCH cyc=%0d pe=%0d got=%08x exp=%08x",
                                 cycles, i, sum_o[i*32+:32], m_sum[i]);
                end
                if (carry_o[i*32+:32] !== m_carry[i]) begin
                    errors = errors + 1;
                    if (errors <= 10)
                        $display("ROW_CORE_CARRY_MISMATCH cyc=%0d pe=%0d got=%08x exp=%08x",
                                 cycles, i, carry_o[i*32+:32], m_carry[i]);
                end
            end
            cycles = cycles + 1;
        end
    endtask

    initial begin
        for (i=0;i<16;i=i+1) begin
            m_sum[i] = 0;
            m_carry[i] = 0;
        end

        repeat (3) @(negedge clk);
        rst_n = 1;
        @(negedge clk);

        for (cyc=0; cyc<30000; cyc=cyc+1) begin
            check_all();

            // 激励：随机乘积和行发射；load周期性插入以验证其最高优先级。
            valid = (($random(seed) & 7) != 0);
            for (i=0;i<16;i=i+1)
                product[i*22+:22] = $random(seed);

            if (load_gap == 0) begin
                load = 1;
                load_gap = 2500;
            end else begin
                load = 0;
                load_gap = load_gap - 1;
            end

            if (issue_gap == 0) begin
                row_issue = 1;
                row_select = ($random(seed) & 3);
                issue_gap = 2 + ($random(seed) & 7);
                if (($random(seed) & 15) == 0) issue_gap = 0; // 偶尔连续发射
            end else begin
                row_issue = 0;
                issue_gap = issue_gap - 1;
            end

            // 参考模型：load > finalize > valid，全部使用边沿前的旧状态。
            for (i=0;i<16;i=i+1) begin
                old_sum = m_sum[i];
                old_carry = m_carry[i];
                p32 = {{10{product[i*22+21]}}, product[i*22+:22]};
                if (load) begin
                    m_sum[i] = 0;
                    m_carry[i] = 0;
                end else if (row_issue && (row_select == 2'(i/4))) begin
                    m_sum[i] = old_sum + old_carry; // 共享加法写回原sum
                    m_carry[i] = 0;                 // 写回同时清carry
                end else if (valid) begin
                    m_sum[i] = old_sum ^ old_carry ^ p32;
                    m_carry[i] = ((old_sum & old_carry) |
                                  (old_sum & p32) |
                                  (old_carry & p32)) << 1;
                end
            end

            @(negedge clk);
        end

        // 冲刷：撤销发射，等待最后状态稳定后逐拍检查。
        valid = 0; load = 0; row_issue = 0; product = '0;
        repeat (4) begin
            check_all();
            @(negedge clk);
        end

        $display("TB_ROW_CORE_RESULT cycles=%0d pe_checks=%0d errors=%0d", cycles, pe_checks, errors);
        if (errors != 0) $fatal(1, "TB_ROW_CORE FAIL");
        $display("TB_ROW_CORE PASS");
        $finish;
    end
endmodule
