`timescale 1ns/1ps
// 完整4×4 PE集成逐拍验证：16个三拍乘法器 + CSA两数寄存器 +
// 4选1行MUX + 4个32位回绕加法 + finalize写回。
// 参考模型复现kwt_mul/kwt_csa32的逐拍行为，覆盖零乘数、load和行切换。
module tb_row_full;
    logic clk=0, rst_n=0;
    logic [47:0] a_rows=0;
    logic [39:0] b_cols=0;
    logic valid=0, load=0, row_issue=0;
    logic [1:0] row_select=0;
    wire [16*32-1:0] sum_o, carry_o;

    adder150_row_full dut(.clk(clk),.rst_n(rst_n),.a_rows(a_rows),.b_cols(b_cols),
        .valid(valid),.load(load),.row_issue(row_issue),.row_select(row_select),
        .sum_o(sum_o),.carry_o(carry_o));

    always #3.333333 clk = ~clk; // 功能验证时钟，不参与综合STA

    logic [31:0] m_sum[0:15];    // 参考模型sum
    logic [31:0] m_carry[0:15];  // 参考模型carry
    logic [2:0] m_vq[0:15];      // 乘法器valid流水
    logic [2:0] m_eq[0:15];      // 乘法器enable流水
    logic signed [11:0] m_aq[0:15];
    logic signed [9:0]  m_bq[0:15];
    logic signed [17:0] m_low[0:15];
    logic signed [16:0] m_high[0:15];
    logic signed [21:0] m_prod[0:15];

    logic signed [11:0] a_pe;
    logic signed [9:0]  b_pe;
    logic nz;
    logic [2:0] ov, oe;
    logic signed [21:0] old_prod, new_prod;
    logic [31:0] old_sum, old_carry, p32;
    integer errors=0, pe_checks=0, cycles=0, i, cyc;
    integer seed=32'h5EED_1234;
    integer issue_gap=4;
    integer load_gap=1200;
    integer zidx;
    integer mi;

    // 按当前输入推进一拍参考模型；乘法器流水和CSA优先级均与RTL一致。
    task automatic model_step;
        begin
            for (mi=0;mi<16;mi=mi+1) begin
                a_pe = $signed(a_rows[(mi/4)*12 +: 12]);
                b_pe = $signed(b_cols[(mi%4)*10 +: 10]);
                nz = (a_pe != 0) && (b_pe != 0);
                ov = m_vq[mi];
                oe = m_eq[mi];
                old_prod = m_prod[mi];
                old_sum = m_sum[mi];
                old_carry = m_carry[mi];

                // 乘法器第三级：合并低5位和高5位部分积（使用旧low_q/high_q）。
                new_prod = oe[1] ? ({{4{m_low[mi][17]}}, m_low[mi]} +
                                    ({{5{m_high[mi][16]}}, m_high[mi]} << 5)) : old_prod;
                if (oe[0]) begin
                    m_low[mi] = m_aq[mi] * $signed({1'b0, m_bq[mi][4:0]});
                    m_high[mi] = m_aq[mi] * $signed(m_bq[mi][9:5]);
                end
                if (valid && nz) begin
                    m_aq[mi] = a_pe;
                    m_bq[mi] = b_pe;
                end
                m_vq[mi] = {ov[1:0], valid};
                m_eq[mi] = {oe[1:0], valid && nz};
                m_prod[mi] = new_prod;

                // CSA下一状态：load > finalize > 乘积有效更新。
                if (load) begin
                    m_sum[mi] = 0;
                    m_carry[mi] = 0;
                end else if (row_issue && (row_select == 2'(mi/4))) begin
                    m_sum[mi] = old_sum + old_carry; // 共享32位加法写回
                    m_carry[mi] = 0;
                end else if (ov[2] && oe[2]) begin
                    p32 = {{10{old_prod[21]}}, old_prod};
                    m_sum[mi] = old_sum ^ old_carry ^ p32;
                    m_carry[mi] = ((old_sum & old_carry) |
                                  (old_sum & p32) |
                                  (old_carry & p32)) << 1;
                end
            end
        end
    endtask

    task automatic check_all;
        begin
            for (i=0;i<16;i=i+1) begin
                pe_checks = pe_checks + 2; // sum和carry各检查一次
                if (sum_o[i*32+:32] !== m_sum[i]) begin
                    errors = errors + 1;
                    if (errors <= 10)
                        $display("ROW_FULL_SUM_MISMATCH cyc=%0d pe=%0d got=%08x exp=%08x",
                                 cycles, i, sum_o[i*32+:32], m_sum[i]);
                end
                if (carry_o[i*32+:32] !== m_carry[i]) begin
                    errors = errors + 1;
                    if (errors <= 10)
                        $display("ROW_FULL_CARRY_MISMATCH cyc=%0d pe=%0d got=%08x exp=%08x",
                                 cycles, i, carry_o[i*32+:32], m_carry[i]);
                end
            end
            cycles = cycles + 1;
        end
    endtask

    initial begin
        for (i=0;i<16;i=i+1) begin
            m_sum[i]=0; m_carry[i]=0; m_vq[i]=0; m_eq[i]=0;
            m_aq[i]=0; m_bq[i]=0; m_low[i]=0; m_high[i]=0; m_prod[i]=0;
        end

        repeat (3) @(negedge clk);
        rst_n = 1;
        @(negedge clk);

        for (cyc=0; cyc<25000; cyc=cyc+1) begin
            check_all();

            // 激励：定向段制造满幅乘积，随后随机；零行/零列验证零乘数冻结。
            if (cyc < 200) begin
                valid = 1;
                a_rows = {12'sh7FF, 12'sh001, 12'sh800, 12'shFFF};
                b_cols = {10'sh3FF, 10'sh001, 10'sh200, 10'sh1FF};
            end else begin
                valid = (($random(seed) & 3) != 0);
                a_rows = {$random(seed), $random(seed)};
                b_cols = {$random(seed), $random(seed)};
                if (($random(seed) & 31) == 0) begin
                    zidx = $random(seed) & 3;
                    a_rows[12*zidx +: 12] = 0;
                end
                if (($random(seed) & 31) == 0) begin
                    zidx = $random(seed) & 3;
                    b_cols[10*zidx +: 10] = 0;
                end
            end

            if (load_gap == 0) begin
                load = 1;
                load_gap = 3000;
            end else begin
                load = 0;
                load_gap = load_gap - 1;
            end

            if (issue_gap == 0) begin
                row_issue = 1;
                row_select = ($random(seed) & 3);
                issue_gap = 2 + ($random(seed) & 7);
                if (($random(seed) & 15) == 0) issue_gap = 0;
            end else begin
                row_issue = 0;
                issue_gap = issue_gap - 1;
            end

            // 参考模型：先算乘法器下一状态，再用边沿前乘积/valid/状态算CSA。
            model_step();

            @(negedge clk);
        end

        // 冲刷：撤销发射后乘法流水仍有在途项，继续按拍推进模型直到排空。
        valid = 0; load = 0; row_issue = 0; a_rows = '0; b_cols = '0;
        repeat (8) begin
            check_all();
            model_step();
            @(negedge clk);
        end

        $display("TB_ROW_FULL_RESULT cycles=%0d pe_checks=%0d errors=%0d", cycles, pe_checks, errors);
        if (errors != 0) $fatal(1, "TB_ROW_FULL FAIL");
        $display("TB_ROW_FULL PASS");
        $finish;
    end
endmodule
