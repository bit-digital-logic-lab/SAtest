// 独立实验：四路共享行加法的完整4×4 PE集成（含16个三拍乘法器）。
// 16个原kwt_pe_csa → 每列4选1行MUX → 4个32位回绕加法 →
// 原PE的finalize写回选择/使能。用于确认加入乘法器后整体块的最差时序。
// 本模块不修改hardware/rtl主线；上传链和shift不在本实验范围，psum_in固定零。
module adder150_row_full (
    input  logic             clk, rst_n,     // 时钟、低有效异步复位
    input  logic [47:0]      a_rows,         // 四行×12位激活
    input  logic [39:0]      b_cols,         // 四列×10位权重
    input  logic             valid,          // 乘法流水有效
    input  logic             load,           // 广播装载（零值）
    input  logic             row_issue,      // 本拍选出一行
    input  logic [1:0]       row_select,     // 被选行号
    output logic [16*32-1:0] sum_o,          // 16个PE的sum寄存器观察口
    output logic [16*32-1:0] carry_o         // 16个PE的carry寄存器观察口
);
    kwt_psum_if pe_in[0:15]();  // 每个PE的链后继输入，本实验固定零
    kwt_psum_if pe_out[0:15](); // 每个PE的原sum寄存器输出
    logic [31:0] carries[0:15]; // 每个PE的原carry寄存器
    logic [31:0] lane_sum[0:3]; // 四列共享加法结果

    for (genvar i=0;i<16;i++) begin : zero_in
        assign pe_in[i].data = '0; // 上传/下载路径不在本实验范围。
    end

    for (genvar c=0;c<4;c++) begin : lanes
        // 先按固定行号展开interface引用，再用row_select做4选1，避免动态interface寻址。
        logic [31:0] sums[0:3];
        logic [31:0] lane_carries[0:3];
        for (genvar rr=0;rr<4;rr++) begin : pick
            assign sums[rr]         = pe_out[rr*4+c].data; // 静态索引第rr行第c列。
            assign lane_carries[rr] = carries[rr*4+c];     // 静态索引同位置carry。
        end
        assign lane_sum[c] = sums[row_select] + lane_carries[row_select]; // 4选1后32位加法。
    end

    for (genvar r=0;r<4;r++) begin : rows
        for (genvar c=0;c<4;c++) begin : cols
            localparam int IDX = r*4+c; // 当前PE索引
            // 原PE：三拍乘法 + 两数CSA；finalize把共享加法结果写回原sum寄存器。
            kwt_pe_csa u_pe(
                .clk(clk), .rst_n(rst_n),
                .a($signed(a_rows[r*12+:12])),
                .b($signed(b_cols[c*10+:10])),
                .compute(valid), .init(load), .shift(1'b0),
                .finalize(row_issue && (row_select == 2'(r))),
                .final_data(lane_sum[c]),
                .carry_data(carries[IDX]),
                .psum_in(pe_in[IDX]), .psum_out(pe_out[IDX])
            );
            assign sum_o[IDX*32+:32]   = pe_out[IDX].data; // 观察原sum寄存器。
            assign carry_o[IDX*32+:32] = carries[IDX];     // 观察原carry寄存器。
        end
    end
endmodule
