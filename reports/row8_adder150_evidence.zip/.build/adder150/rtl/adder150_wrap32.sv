// 独立实验：32位INT32回绕加法，输入寄存器→组合加法→输出寄存器，每拍更新。
// 端口到端口延迟为两拍（输入寄存器一拍、输出寄存器一拍），内部加法路径为一拍。
module adder150_wrap32 (
    input  logic        clk, rst_n, // 时钟、低有效异步复位
    input  logic [31:0] a, b,       // 外部操作数
    output logic [31:0] sum         // 回绕和
);
    logic [31:0] a_q, b_q; // 输入寄存器，作为加法器的发射端
    logic [31:0] sum_q;    // 输出寄存器，每拍无条件更新
    logic [31:0] add;      // 组合加法结果

    assign add = a_q + b_q; // 32位加法自然丢弃bit32，得到INT32回绕

    // 输入/输出两级寄存器均每拍更新；加法本身不跨拍，不使用enable或多周期约束。
    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin // 异步复位清空两级寄存器。
            a_q <= '0; b_q <= '0; sum_q <= '0;
        end else begin
            a_q <= a;     // 每拍采样外部A。
            b_q <= b;     // 每拍采样外部B。
            sum_q <= add; // 使用上一拍输入寄存器的和，每拍更新。
        end
    end

    assign sum = sum_q; // 输出寄存器直连端口。
endmodule
