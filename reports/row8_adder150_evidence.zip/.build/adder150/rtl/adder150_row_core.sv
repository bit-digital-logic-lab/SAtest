// 独立实验：四路共享行加法的4×4集成路径（不含乘法器）。
// 16个原kwt_csa32 PE寄存器 → 每列4选1行MUX → 4个32位回绕加法 →
// 原PE的finalize写回选择/使能。用于单独测量“行MUX+加法+写回”路径。
// 本模块不修改hardware/rtl主线文件；load装载零值，仅保留原PE装载优先级。
module adder150_row_core (
    input  logic               clk, rst_n, // 时钟、低有效异步复位
    input  logic [16*22-1:0]   product,    // 16个PE的22位有符号乘积
    input  logic               valid,      // 广播乘积有效
    input  logic               load,       // 广播装载（装载零值，仅测试优先级）
    input  logic               row_issue,  // 本拍选出一行送入共享加法
    input  logic [1:0]         row_select, // 被选行号
    output logic [16*32-1:0]   sum_o,      // 16个PE的sum寄存器观察口
    output logic [16*32-1:0]   carry_o     // 16个PE的carry寄存器观察口
);
    logic [31:0] sums[0:15];    // 原PE的sum寄存器，索引=行×4+列
    logic [31:0] carries[0:15]; // 原PE的carry寄存器
    logic [31:0] lane_sum[0:3]; // 四列共享加法的组合结果

    for (genvar c=0;c<4;c++) begin : lanes
        // 每列一个4选1行MUX，选择当前行PE的sum/carry；动态索引展开为行MUX。
        logic [31:0] sel_sum, sel_carry;
        assign sel_sum   = sums[row_select*4+c];    // 4选1：本列被选行的sum。
        assign sel_carry = carries[row_select*4+c]; // 4选1：本列被选行的carry。
        assign lane_sum[c] = sel_sum + sel_carry;   // 32位回绕加法，bit32丢弃。
        // lane_sum直接作为本列四个PE的final_data，写回路径只经过PE的finalize MUX。
    end

    for (genvar r=0;r<4;r++) begin : rows
        for (genvar c=0;c<4;c++) begin : cols
            localparam int IDX = r*4+c; // 当前PE在16个原寄存器中的位置
            // 原PE两数寄存器；finalize由本拍row_issue和行号组合产生，
            // 与原4×4块“写回选择/使能寄存器”的优先级一致。
            kwt_csa32 u_csa(
                .clk(clk), .rst_n(rst_n),
                .load(load), .load_data('0), // 上传数据路径不在本实验范围，装载零值。
                .valid(valid),
                .product($signed(product[IDX*22+:22])),
                .finalize(row_issue && (row_select == 2'(r))),
                .final_data(lane_sum[c]),
                .sum_data(sums[IDX]), .carry_data(carries[IDX])
            );
            assign sum_o[IDX*32+:32]   = sums[IDX];   // 直接观察原sum寄存器。
            assign carry_o[IDX*32+:32] = carries[IDX]; // 直接观察原carry寄存器。
        end
    end
endmodule
