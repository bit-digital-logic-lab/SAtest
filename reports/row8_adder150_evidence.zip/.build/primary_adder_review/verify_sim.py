"""主审重新编译并运行DS三个相关实验及独立普通整数参考，日志只写.build。"""
from pathlib import Path
import subprocess,json,re
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'.build/primary_adder_review';DS=ROOT/'.build/adder150'
cases=[('add32','tb_add32',[DS/'rtl/adder150_wrap32.sv',DS/'tb/tb_add32.sv'],False),
 ('row_core','tb_row_core',[ROOT/'hardware/rtl/kwt_csa32.sv',DS/'rtl/adder150_row_core.sv',DS/'tb/tb_row_core.sv'],False),
 ('row_full','tb_row_full',[ROOT/'hardware/rtl'/f for f in ['kwt_interfaces.sv','kwt_mul.sv','kwt_csa32.sv','kwt_pe_csa.sv']]+[DS/'rtl/adder150_row_full.sv',DS/'tb/tb_row_full.sv'],True),
 ('ordinary_math','tb_math',[ROOT/'hardware/rtl/kwt_csa32.sv',DS/'rtl/adder150_row_core.sv',OUT/'tb_math.sv'],False)]
results=[]
for name,top,sources,verilator in cases:
 d=OUT/'sim'/name;d.mkdir(parents=True,exist_ok=True);binary=d/('tb' if verilator else 'tb.vvp')
 command=(['verilator','--binary','--timing','--assert','-Wno-fatal','-j','4','--top-module',top,'--Mdir',str(d/'obj'),'-o',str(binary)] if verilator else ['iverilog','-g2012','-s',top,'-o',str(binary)])+list(map(str,sources))
 with (d/'compile.log').open('w') as log: rc=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT).returncode
 assert rc==0,(name,'compile',rc)
 with (d/'sim.log').open('w') as log: rc=subprocess.run([str(binary)] if verilator else ['vvp',str(binary)],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT).returncode
 content=(d/'sim.log').read_text();assert rc==0 and 'PASS' in content,(name,'sim',rc)
 result={'case':name,'compile_rc':0,'run_rc':rc,'summary':[line for line in content.splitlines() if 'RESULT' in line or 'PASS' in line]};results.append(result);print(result,flush=True)
 (OUT/'simulation_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
