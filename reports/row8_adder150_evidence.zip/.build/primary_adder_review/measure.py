"""主审独立复测DS源文件，采用主线相同库和约束，单独保存原始映射与STA证据。"""
from pathlib import Path
import importlib.util,subprocess,json,re,hashlib
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'.build/primary_adder_review';DS=ROOT/'.build/adder150'
spec=importlib.util.spec_from_file_location('shared_flow',ROOT/'hardware/synth.py');flow=importlib.util.module_from_spec(spec);spec.loader.exec_module(flow)
areas={n:float(a) for n,a in re.findall(r'cell\s*\(([^)]+)\)\s*\{.*?\barea\s*:\s*([0-9.eE+-]+)',flow.LIB.read_text(),re.S)}
results=[]
for top in ['adder150_wrap32','adder150_row_core','adder150_row_full']:
 d=OUT/top;d.mkdir(parents=True,exist_ok=True)
 sources=[DS/'rtl'/f'{top}.sv']
 if top!='adder150_wrap32': sources=[ROOT/'hardware/rtl/kwt_interfaces.sv',ROOT/'hardware/rtl/kwt_mul.sv',ROOT/'hardware/rtl/kwt_csa32.sv',ROOT/'hardware/rtl/kwt_pe_csa.sv',*sources]
 hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
 (d/'abc.constr').write_text('set_driving_cell BUFX0P5H7L\nset_load 10\n')
 (d/'synth.ys').write_text(f'''read_slang --top {top} {' '.join(map(str,sources))}
synth -top {top} -flatten -noabc
dfflibmap -liberty {flow.LIB}
abc -liberty {flow.LIB} -D 6666.667 -constr {d/'abc.constr'}
clean
hilomap -singleton -hicell TIEHIH7L Z -locell TIELOH7L Z
setundef -zero
clean
read_liberty -lib {flow.LIB}
check -mapped -assert
tee -o {d/'stat.json'} stat -json -liberty {flow.LIB}
write_json {d/'netlist.json'}
''')
 flow.run_logged(['yosys','-Q','-T','-m','slang','-s',str(d/'synth.ys')],d/'synth.log')
 module=json.loads((d/'netlist.json').read_text())['modules'][top]
 ports=flow.scalar_netlist(module,top,d/'netlist.v')
 sdc='create_clock -name clk -period 6.666667 [get_ports clk]\nset_clock_uncertainty 0.1 [get_clocks clk]\nset_clock_transition 0.1 [get_clocks clk]\n'
 for p,direction in ports:
  if direction=='input' and p!='clk': sdc+=f'set_input_delay 0.5 -clock clk [get_ports {{{p}}}]\nset_input_transition 0.1 [get_ports {{{p}}}]\n'
  elif direction=='output':sdc+=f'set_output_delay 0.5 -clock clk [get_ports {{{p}}}]\nset_load 0.01 [get_ports {{{p}}}]\n'
 (d/'design.sdc').write_text(sdc)
 (d/'sta.tcl').write_text(f'''read_liberty {flow.LIB}
read_verilog netlist.v
link_design {top}
read_sdc design.sdc
check_setup -verbose > coverage.rpt
report_worst_slack -digits 6 > slack.rpt
report_tns -digits 6 > tns.rpt
report_checks -path_delay max -group_count 1 -fields {{capacitance slew}} -digits 6 > critical.rpt
exit
''')
 flow.run_logged([str(flow.STA),'-exit','sta.tcl'],d/'sta.log')
 assert not re.search(r'^Error:',(d/'sta.log').read_text(),re.M)
 area=sum(areas[c['type']] for c in module['cells'].values());stat=json.loads((d/'stat.json').read_text())['modules']['\\'+top]
 assert abs(area-stat['area'])<0.01
 assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in hashes.items())
 slack=float(re.search(r'worst slack\s+([+\-\d.eE]+)',(d/'slack.rpt').read_text()).group(1));tns=float(re.search(r'tns\s+([+\-\d.eE]+)',(d/'tns.rpt').read_text()).group(1))
 result={'top':top,'area_um2':area,'cells':len(module['cells']),'worst_slack_ns':slack,'tns_ns':tns,'source_sha256':hashes,'lib_sha256':hashlib.sha256(flow.LIB.read_bytes()).hexdigest()}
 (d/'result.json').write_text(json.dumps(result,indent=2)+'\n');results.append(result);print(json.dumps(result),flush=True)
 (OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
