`timescale 1ns/1ps
// 主审独立数值验证：只维护普通INT32累加值，不复制CSA的异或/进位算法。
// 每拍检查16个PE的sum+carry，覆盖零值、负数、随机出行及load/finalize优先级。
module tb_math;
    logic clk=0,rst_n=0; // 时钟与复位
    logic valid=0,load=0,row_issue=0; // 实验模块控制
    logic [1:0] row_select=0; // 共享加法行号
    logic [351:0] product=0; // 16路22位乘积
    wire [511:0] sums,carries; // 16路两数表示
    logic [31:0] golden[0:15],actual; // 独立普通整数累加参考
    integer seed=32'h3726AB17,checks=0; // 确定性激励及检查数
    adder150_row_core dut(.clk(clk),.rst_n(rst_n),.product(product),.valid(valid),
        .load(load),.row_issue(row_issue),.row_select(row_select),.sum_o(sums),.carry_o(carries));
    always #5 clk=~clk; // 功能时钟；频率是否满足以STA判断。
    initial begin
        for(int i=0;i<16;i++) golden[i]=0; // 参考状态与DUT复位一致。
        repeat(3) @(negedge clk);
        rst_n=1;
        for(int t=0;t<5000;t++) begin
            load=(t%613==0); valid=(t%7!=0); row_issue=(t%3==0); row_select=2'(t);
            for(int i=0;i<16;i++) begin
                product[i*22+:22]=22'($random(seed)); // 不同行独立正负数据。
                if(t%17==0) product[i*22+:22]=0; // 验证零位置。
                if(load) golden[i]=0; // 上传优先，清空数值。
                else if(row_issue && row_select==2'(i/4)) begin end // 最终相加不改变数学总和。
                else if(valid) golden[i]=golden[i]+32'($signed(product[i*22+:22])); // 普通加法独立参考。
            end
            @(posedge clk); #1;
            for(int i=0;i<16;i++) begin
                actual=sums[i*32+:32]+carries[i*32+:32]; // 两数表示还原数学总和。
                if(actual!==golden[i]) $fatal(1,"math mismatch t=%0d pe=%0d got=%h expected=%h",t,i,actual,golden[i]);
                checks++;
            end
            @(negedge clk);
        end
        $display("PRIMARY_MATH_PASS checks=%0d",checks);
        $finish;
    end
endmodule
