read_liberty /home/yang/yosys-sta/pdk/icsprout55/IP/STD_cell/ics55_LLSC_H7C_V1p10C100/ics55_LLSC_H7CL/liberty/ics55_LLSC_H7CL_ss_rcworst_1p08_125_nldm.lib
read_verilog netlist.v
link_design adder150_wrap32
read_sdc design.sdc
check_setup -verbose > coverage.rpt
report_worst_slack -digits 6 > slack.rpt
report_tns -digits 6 > tns.rpt
report_checks -path_delay max -group_count 1 -fields {capacitance slew} -digits 6 > critical.rpt
exit
