# DS-2：16×16 直接扩大矩阵（每 PE 1 个乘法器）

范围：只做计算核心（256 个单乘 PE 的功能与结构），`psum_in=0`、`init=shift=0`。
不做 150MHz 综合/STA、不给面积数字，由主代理统一跑。未改动本目录以外的任何文件。

## 1. 文件清单

| 文件 | 作用 |
| --- | --- |
| `rtl/kwt_pe_m1.sv` | 单乘 PE：1 个 `kwt_mul` + 1 个 `kwt_acc28`，单拍 28 位 CPA |
| `rtl/kwt_flat16.sv` | 16×16 扁平阵列，256 个 `kwt_pe_m1`，A 按行/B 按列广播 |
| `tb/tb_kwt_pe_m1.sv` | 单 PE 逐拍独立参考台（先验证三级流水与 valid 对齐） |
| `tb/tb_kwt_flat16.sv` | 16×16×K8 逐点比较台（256 点/拍，6 个用例） |
| `run.sh` | 一键：编译+跑两个台 → Yosys 结构检查 → PASS/错误数门限判定 |
| `run.log` | Verilator 编译与运行日志（含 PASS 行、编译报告） |
| `synth_check.log` | Yosys `read_slang` + `hierarchy -check` + `proc; opt; check -assert; stat` 日志 |
| `obj/pe/`、`obj/flat16/` | Verilator 生成物（`--Mdir`），可删除后由 `run.sh` 重生成 |

只编译本目录 RTL + 明确列出的公共 RTL（不复制同名模块）：

- `hardware/rtl/kwt_mul.sv`（三级 A12×W10）
- `hardware/rtl/kwt_interfaces.sv`（`kwt_psum_if`）
- `hardware/versions/dual/rtl/kwt_acc28.sv`（**直接复用双乘版的 ACC28**，未复制）

## 2. 端口

```systemverilog
module kwt_pe_m1 (
    input logic clk, rst_n,
    input logic signed [11:0] a,            // 本行该 K 位置的激活
    input logic signed [9:0]  b,            // 本列该 K 位置的权重
    input logic compute, init, shift,       // 发射 / 装和 / 移位
    kwt_psum_if.sink   psum_in,             // 32 位旧和（阵列中接 0）
    kwt_psum_if.source psum_out             // {{4{acc[27]}},acc}
);

module kwt_flat16 (
    input  logic clk, rst_n,
    input  logic signed [16*12-1:0] a_row,  // [12*r +: 12] = 第 r 行 A
    input  logic signed [16*10-1:0] b_col,  // [10*c +: 10] = 第 c 列 B
    input  logic valid,                     // 统一发射（接各 PE 的 compute）
    output logic [256*32-1:0] out           // [32*(16*r+c) +: 32]，符号扩展 INT32
);
```

`kwt_flat16` 顶层无接口端口：`kwt_psum_if zero_psum()` 驱动全部 `psum_in`（`data=0`），
每个 PE 的 `psum_out` 接 `kwt_psum_if pe_psum[0:255]` 数组端点后扇出到 `out`。
`init=shift=1'b0`，因此阵列侧不含上传/下载通路。

## 3. PE 结构

```text
a,b ──► kwt_mul（3 级：操作数寄存 → low5/high5 两段部分积 → 合并）──► product[21:0]
                                        │
                       p = e ? {{6{product[21]}},product} : 28'b0   （零通道屏蔽）
                                        │
        acc ────────────────────────► [28 位单拍 CPA: acc + p] ──► acc
                                        (kwt_acc28: sum_bits=acc, carry_bits=p,
                                         load=init||shift, valid=v&&e)
psum_out.data = {{4{acc[27]}},acc}
```

- 无三压二：`sum_bits=acc`、`carry_bits=p`，一个 28 位加法器/PE/拍，等效 SPEC 允许的“单拍 28 位 CPA”。
- 每拍 1 个 MAC，三级流水后可背靠背每拍出一个结果，无反压、无 busy。
- 与 dual 版 PE 的差别：去掉第 2 个乘法器和 `kwt_csa28`，其余（乘法器、ACC28、零值 CE 语义、接口）保持一致。
- `kwt_flat16` 仅 6 个端口；A 扇出 16（同一行 16 个 PE）、B 扇出 16（同一列），未插缓冲。

## 4. 测试覆盖与实际结果

运行命令（`run.sh` 内部；已实际执行，`./run.sh` 退出码 0）：

```bash
verilator --binary --timing --assert -Wno-fatal -O3 -j 4 --Mdir obj/pe -o pe_sim \
  --top-module tb_kwt_pe_m1 tb/tb_kwt_pe_m1.sv rtl/kwt_pe_m1.sv \
  hardware/rtl/kwt_mul.sv hardware/rtl/kwt_interfaces.sv hardware/versions/dual/rtl/kwt_acc28.sv
./obj/pe/pe_sim

verilator --binary --timing --assert -Wno-fatal -O3 -j 4 --Mdir obj/flat16 -o flat16_sim \
  --top-module tb_kwt_flat16 tb/tb_kwt_flat16.sv rtl/kwt_pe_m1.sv rtl/kwt_flat16.sv \
  hardware/rtl/kwt_mul.sv hardware/rtl/kwt_interfaces.sv hardware/versions/dual/rtl/kwt_acc28.sv
./obj/flat16/flat16_sim

yosys -p "plugin -i slang; read_slang --top kwt_flat16 --single-unit <同上5个文件>; \
          hierarchy -check -top kwt_flat16; proc; opt; check -assert; stat"
```

单 PE 台（`tb_kwt_pe_m1`）：600 拍随机流，夹入零 A/零 B、±端点（−2048×−512、2047×511）、
每 17 拍一个空拍，末尾 4 拍排空 + 两次装和（`shift`，含 `0xf8000000`、`0x7f`）。
每拍独立 28 位模运算参考与 DUT 逐拍比较，同时检查 `out_valid` 三级对齐和乘法结果。

> 实际结果：`PE_PASS checks=610 mul_cases=600 stages=3 acc_bits=28`

16×16 阵列台（`tb_kwt_flat16`）：每用例 K=8 拍连续计算 + 4 拍排空 + 1 拍复位，共 13 拍×256 点。
每个 PE 独立 64 位整数累加参考，逐拍比较 256 个输出（28 位模 2^28 截断后符号扩展）。

| 用例 | 内容 | 结果 |
| --- | --- | --- |
| 1 | 全零矩阵 | 通过 |
| 2 | 单点非零 (r=3,c=11,K=0..1) | 通过 |
| 3 | 随机小矩阵 A∈[-8,7]、B∈[-4,3] | 通过 |
| 4 | 满量程随机 A∈[-2048,2047]、B∈[-512,511] | 通过 |
| 5 | 全 −2048 × −512（每拍每点 +2^20） | 通过 |
| 6 | 零 A/零 B 混合（验证零通道不吞掉同拍其他非零乘积） | 通过 |

另加 768 次**字面值点检**（不经过参考模型）：用例 1 全 0、用例 2 只允许 (3,11)=−66 且其余为 0、
用例 5 每点为 8×2^20=0x00800000，防止“参考和 DUT 同错”导致空转。

> 实际结果：`FLAT16_PASS checks=20736 errs=0 cases=6 k=8 pe=256`
> （19968 次参考比较 + 768 次字面值点检；0 失配）

`run.sh` 的结果门限（不只看退出码）：必须同时满足
`PE_PASS` 标记存在、`FLAT16_PASS ... errs=0` 存在、`Found and reported 0 problems`、
`512 $mul` 出现在结构检查里、日志中 `MISMATCH|FAIL|%Error|Assertion failed|$fatal` 行数为 0，
本次输出 `pe_pass_markers=1 flat16_pass_markers=1 synth_0problems=1 mul_cells_512=1 error_lines=0` → `OVERALL_PASS`。

## 5. Yosys 结构检查结论

`read_slang` 读入后**内部自动扁平化**（层次名如 `g_row[14].g_col[2].u_pe.u_acc.sum` 都在 `kwt_flat16` 内），
`hierarchy -check` + `proc; opt; check -assert` 报 `Found and reported 0 problems`。`stat -width` 结构如下：

| cell | 数量 | 含义 |
| --- | --- | --- |
| `$mul_17` | 256 | 每 PE：`a_q[11:0] × b_q[4:0]`（kwt_mul 低 5 位段） |
| `$mul_18` | 256 | 每 PE：`a_q[11:0] × b_q[9:5]`（高 5 位有符号段） |
| `$add_22` | 256 | 每 PE：第三级合并两段部分积 |
| `$add_28` | 256 | 每 PE：ACC28 的单拍 28 位 CPA |
| `$mux_28` | 256 | 每 PE：零通道乘积屏蔽 |
| `$logic_and_1` | 768 | 每 PE：2 个 `nonzero` + 1 个 `in_valid&&nonzero` |
| `$reduce_bool_32` | 32 | 16 行 A / 16 列 B 的零检测（广播共享，只有 32 个） |
| `$adff_3` | 512 | 每 PE 2×3 位：`valid_q`、`enable_q` |
| `$adffe` 10/12/17/18/22/28 | 各 256 | 每 PE：`b_q`、`a_q`、`high_q`、`low_q`、`product`、`acc` |

- DFF 位数合计 256×113 = 28928 位（`a_q12+b_q10+low_q18+high_q17+product22+valid3+enable3+acc28`）。
- **`512 $mul` 不是 512 个 MAC**：本项目 `kwt_mul` 把一个 12×10 乘法拆成 12×5 与 12×5（有符号高段）两个乘法再合并，
  所以 256 个 MAC/拍对应 512 个 `$mul`，与 dual/1 乘的对比口径需一致（主代理综合时注意）。
- 该检查只到 RTL/工艺无关的综合中间表示，`$mul/$add` 未映射到标准单元，**不构成面积或时序结论**。

## 6. 已知限制 / 不确定点

1. **没有面积和时序数字**：按 SPEC 只做 Verilator 功能 + Yosys 结构检查，150MHz/55nm 综合与 STA 由主代理统一做。
2. **阵列侧未覆盖 28 位装载/移位与回绕**：`kwt_flat16` 按要求 `init=shift=0`、`psum_in=0`，
   28 位模 2^28 回绕只在 `tb_kwt_pe_m1` 的 600 拍随机流里覆盖（阵列 8 拍×最大 2^20 无法溢出 2^28）。
   若主代理希望阵列台也测回绕，需要给 `kwt_flat16` 加装和通路（会改变面积口径，故本实验未加）。
3. **零通道屏蔽与 `valid=v&&e` 互为冗余**：用变异测试确认，
   单独去掉 `p=e?product:0` 的屏蔽、或单独把 `valid` 改成 `v`，功能都仍然正确（另一重保护已把该拍压成 0/不更新）；
   两者同时去掉才会错（`tb_kwt_pe_m1` 报 `Assertion failed`）。
   本实验按 SPEC 保留两者（每 PE 256 个 `$mux_28` 因此严格来说不是功能必需），是否在面积对比中省掉由主代理决定。
4. **变异测试（灵敏度验证，非交付物）**：在 `/tmp/opencode/mut` 的副本上验证过
   （a）把 `kwt_flat16` 的 B 改成按行广播 → 阵列台报 `MISMATCH idx=59`；
   （b）同时去掉屏蔽与 `v&&e` → 单 PE 台报 `Assertion failed`。副本目录已删除，仓库内文件未受影响。
5. **A/B 供数未建模**：阵列把 `a_row`/`b_col` 直接连到 256 个 PE，无输入寄存器、无 12/10 位打包选择逻辑，
   扇出 16+16 也未插缓冲。供数压力与 A/B 存储面积需与核心面积分开另算。
6. **Verilator 5.047 devel 的日志小瑕疵**：仿真结束行打印 `$finish at 780ps`（实际 780ns），
   只是单位显示问题；拍数由 `checks` 计数（13 拍×6 用例×256 点 + 768）交叉核对过。
7. 16×16 顶层 Verilator 代码生成较慢（首个 `--binary` 构建约 95s，增量重编约 4s）；仿真本身 <1s。
