#!/usr/bin/env bash
# DS-2实验入口：16×16单乘阵列的功能仿真（Verilator）与结构检查（Yosys read_slang）。
# 只读公共RTL：hardware/rtl/kwt_mul.sv、kwt_interfaces.sv、versions/dual/rtl/kwt_acc28.sv；
# 只写本目录（rtl/tb/obj/run.log/synth_check.log）。不做150MHz综合与STA，由主代理统一执行。
set -uo pipefail
cd "$(dirname "$0")"
ROOT=$(cd ../../.. && pwd) # ds_arr16 → exp_mulwidth → .build → 仓库根
LOG=run.log
SYN=synth_check.log
COMMON="$ROOT/hardware/rtl/kwt_mul.sv $ROOT/hardware/rtl/kwt_interfaces.sv $ROOT/hardware/versions/dual/rtl/kwt_acc28.sv"
PE_SRC="rtl/kwt_pe_m1.sv"
FLAT_SRC="rtl/kwt_pe_m1.sv rtl/kwt_flat16.sv"
mkdir -p obj/pe obj/flat16
: > "$LOG"
: > "$SYN"
status=0

# 通用编译参数：64位时间精度、断言打开、警告不致命但全部打印进日志。
VL="verilator --binary --timing --assert -Wno-fatal -O3 -j 4"

# 1) 单PE台：先验证三级流水与valid对齐的参考模型。
echo "==== [1/3] Verilator build+run tb_kwt_pe_m1 ====" | tee -a "$LOG"
$VL --Mdir obj/pe -o pe_sim --top-module tb_kwt_pe_m1 \
    tb/tb_kwt_pe_m1.sv $PE_SRC $COMMON >> "$LOG" 2>&1
if [ $? -ne 0 ]; then echo "BUILD_FAIL: tb_kwt_pe_m1" | tee -a "$LOG"; status=1; fi
./obj/pe/pe_sim 2>&1 | tee -a "$LOG"
[ ${PIPESTATUS[0]} -eq 0 ] || { echo "RUN_FAIL: tb_kwt_pe_m1" | tee -a "$LOG"; status=1; }

# 2) 16×16阵列台：256点逐点比较。
echo "==== [2/3] Verilator build+run tb_kwt_flat16 ====" | tee -a "$LOG"
$VL --Mdir obj/flat16 -o flat16_sim --top-module tb_kwt_flat16 \
    tb/tb_kwt_flat16.sv $FLAT_SRC $COMMON >> "$LOG" 2>&1
if [ $? -ne 0 ]; then echo "BUILD_FAIL: tb_kwt_flat16" | tee -a "$LOG"; status=1; fi
./obj/flat16/flat16_sim 2>&1 | tee -a "$LOG"
[ ${PIPESTATUS[0]} -eq 0 ] || { echo "RUN_FAIL: tb_kwt_flat16" | tee -a "$LOG"; status=1; }

# 3) Yosys结构检查：read_slang读入层次（内部已扁平化）、proc/opt后check -assert。
# 注意：yosys-slang不支持--allow-toplevel-iface-ports，且顶层无接口端口，故不加该选项。
echo "==== [3/3] Yosys read_slang structural check: kwt_flat16 ====" | tee -a "$SYN"
yosys -p "plugin -i slang; \
  read_slang --top kwt_flat16 --single-unit \
    rtl/kwt_flat16.sv rtl/kwt_pe_m1.sv $COMMON; \
  hierarchy -check -top kwt_flat16; proc; opt; check -assert; stat" >> "$SYN" 2>&1
if [ $? -ne 0 ]; then echo "SYNTH_CHECK_FAIL" | tee -a "$SYN"; status=1; fi

# 4) 结果判定：必须看到PASS字样，且错误计数为0、无断言/致命错误，不能只看退出码。
echo "==== [4/4] result gate ====" | tee -a "$LOG"
pe_ok=$(grep -c "^PE_PASS checks=[0-9]* mul_cases=600" "$LOG")
fl_ok=$(grep -c "^FLAT16_PASS checks=[0-9]* errs=0" "$LOG")
syn_ok=$(grep -c "Found and reported 0 problems" "$SYN")
mul_ok=$(grep -c "^      512   \$mul" "$SYN")
bad=$(grep -cE "MISMATCH|FAIL|%Error|Assertion failed|\\\$fatal" "$LOG" "$SYN" | awk -F: '{s+=$2} END{print s+0}')
echo "pe_pass_markers=$pe_ok flat16_pass_markers=$fl_ok synth_0problems=$syn_ok mul_cells_512=$mul_ok error_lines=$bad" | tee -a "$LOG"
[ "$pe_ok" -ge 1 ] && [ "$fl_ok" -ge 1 ] && [ "$syn_ok" -ge 1 ] && [ "$mul_ok" -ge 1 ] && [ "$bad" -eq 0 ] || status=1
if [ $status -eq 0 ]; then
  echo "OVERALL_PASS" | tee -a "$LOG"
else
  echo "OVERALL_FAIL" | tee -a "$LOG"
fi
exit $status
