#!/usr/bin/env bash
# 可复现实验：Verilator单PE功能回归 + Yosys read_slang结构检查（不做综合/STA）。
# 只读公共RTL与dual版kwt_acc28，不复制同名模块；产物全部写在本目录。
set -uo pipefail

HERE=$(cd "$(dirname "$0")" && pwd)
ROOT=$(cd "$HERE/../../.." && pwd) # ds_pe→exp_mulwidth→.build→仓库根
RTL=$HERE/rtl
TB=$HERE/tb
OBJ=$HERE/obj
RUNLOG=$HERE/run.log
SYNLOG=$HERE/synth_check.log

COMMON=("$ROOT/hardware/rtl/kwt_interfaces.sv"
        "$ROOT/hardware/rtl/kwt_mul.sv"
        "$ROOT/hardware/versions/dual/rtl/kwt_acc28.sv")

mkdir -p "$OBJ"
: > "$RUNLOG"
: > "$SYNLOG"
status=0

# 编译并运行一个PE顶层；功能判定看日志里的PE_PASS/errors=0，不只看退出码。
run_pe() {
    local pe=$1
    local top=tb_$pe
    local bin=$OBJ/$top/V$top
    local clog=$OBJ/$top/compile.log
    mkdir -p "$OBJ/$top"
    {
        echo "===== VERILATOR top=$top ====="
        echo "cmd: verilator --binary --timing --assert -Wno-fatal -j 4 --top-module $top"
    } >> "$RUNLOG"
    verilator --binary --timing --assert -Wno-fatal -j 4 --top-module "$top" \
        --Mdir "$OBJ/$top" -o "$bin" \
        "${COMMON[@]}" "$RTL/kwt_csa3.sv" "$RTL/$pe.sv" "$TB/$top.sv" \
        > "$clog" 2>&1
    if [ $? -ne 0 ]; then
        echo "COMPILE_FAIL top=$pe log=$clog" | tee -a "$RUNLOG"
        tail -40 "$clog" >> "$RUNLOG"
        status=1
        return
    fi
    "$bin" >> "$RUNLOG" 2>&1
    local rc=$?
    echo "exit=$rc top=$pe" >> "$RUNLOG"
    if [ $rc -ne 0 ]; then
        echo "SIM_FAIL top=$pe exit=$rc" | tee -a "$RUNLOG"
        status=1
    fi
    if ! grep -q "^PE_PASS top=$pe .*errors=0$" "$RUNLOG"; then
        echo "CHECK_FAIL top=$pe (no PE_PASS/errors=0)" | tee -a "$RUNLOG"
        status=1
    fi
    if grep -q "^PE_FAIL" "$RUNLOG"; then
        echo "CHECK_FAIL top=$pe (PE_FAIL seen)" | tee -a "$RUNLOG"
        status=1
    fi
}

# Yosys Slang前端结构检查：读入PE及其接口包装层，只做层级和进程展开。
check_synth() {
    local pe=$1
    local top=${pe}_wrap
    {
        echo "===== YOSYS top=$top (PE=$pe) ====="
        echo "cmd: yosys -m slang -p read_slang/hierarchy/proc/opt/check"
    } >> "$SYNLOG"
    yosys -m slang -p "read_slang --top $top ${COMMON[*]} $RTL/kwt_csa3.sv $RTL/$pe.sv $TB/$top.sv; hierarchy -check -top $top; proc; opt; check -assert; stat" >> "$SYNLOG" 2>&1
    local rc=$?
    if [ $rc -ne 0 ] || grep -qE "^ERROR|Error: " "$SYNLOG"; then
        echo "SYNTH_CHECK_FAIL top=$top exit=$rc" | tee -a "$SYNLOG"
        status=1
    else
        echo "SYNTH_CHECK_PASS top=$top" >> "$SYNLOG"
    fi
}

for pe in kwt_pe_m4 kwt_pe_m8; do
    run_pe "$pe"
done

for pe in kwt_pe_m4 kwt_pe_m8; do
    check_synth "$pe"
done

echo "----- run.log summary -----"
grep -E "^(PE_PASS|PE_FAIL|SIM_FAIL|COMPILE_FAIL|CHECK_FAIL)" "$RUNLOG" || true
echo "----- synth_check.log summary -----"
grep -E "^(SYNTH_CHECK_PASS|SYNTH_CHECK_FAIL|ERROR)" "$SYNLOG" || true
if [ $status -eq 0 ]; then echo "ALL_OK"; else echo "FAILED"; fi
exit $status
