# DS-1：每 PE 4/8 乘法器实验（kwt_pe_m4 / kwt_pe_m8）

本目录按 `.build/exp_mulwidth/SPEC.md` 的 DS-1 节实现，只写本目录，未改
`hardware/rtl/`、`hardware/versions/`、`model/`、`software/` 或仓库其他文件。
功能仿真与结构检查均已实际运行，日志见 `run.log` 与 `synth_check.log`。

## 1. 文件清单

| 路径 | 作用 |
| --- | --- |
| `rtl/kwt_csa3.sv` | 28 位 3:2 压缩器，逐位 `s=a^b^c`、`co=((a&b)|(a&c)|(b&c))<<1` |
| `rtl/kwt_pe_m4.sv` | 4 乘 PE：4×`kwt_mul` + 3×`kwt_csa3` + 1×`kwt_acc28` |
| `rtl/kwt_pe_m8.sv` | 8 乘 PE：8×`kwt_mul` + 7×`kwt_csa3` + 1×`kwt_acc28` |
| `tb/tb_kwt_pe_m4.sv` | m4 单 PE 逐拍独立参考 testbench（775 拍） |
| `tb/tb_kwt_pe_m8.sv` | m8 单 PE 逐拍独立参考 testbench（775 拍） |
| `tb/kwt_pe_m4_wrap.sv` | Yosys 结构检查包装：为接口端口实例化 `kwt_psum_if` |
| `tb/kwt_pe_m8_wrap.sv` | 同上，m8 版本 |
| `run.sh` | 可复现：Verilator 编译运行 + Yosys read_slang 检查 |
| `run.log` | 实际功能仿真日志（含命令、PE_PASS、退出码） |
| `synth_check.log` | 实际 Yosys read_slang 层级/进程检查日志与 cell 统计 |
| `obj/` | Verilator 构建产物与各自 `compile.log`（可重新生成） |

`kwt_acc28.sv` 直接引用 `hardware/versions/dual/rtl/kwt_acc28.sv`，本目录没有复制同名模块。
`kwt_mul.sv`、`kwt_interfaces.sv` 来自 `hardware/rtl/`，均只读。

## 2. 端口

两个模块端口同构，M=8 仅多出 `a4..a7`、`b4..b7`：

```systemverilog
module kwt_pe_m4 (               // m8: a0..a7 / b0..b7
    input logic clk, rst_n,
    input logic signed [11:0] a0,a1,a2,a3,
    input logic signed [9:0]  b0,b1,b2,b3,
    input logic compute, init, shift,
    kwt_psum_if.sink   psum_in,
    kwt_psum_if.source psum_out
);
```

行为与 SPEC 一致：

- 每个通道一个 `kwt_mul`，同一 `compute` 驱动，三级流水；
- `p[i] = e[i] ? {{6{product[i][21]}}, product[i]} : 28'b0`，先符号扩展再按各自
  `out_enable` 清零，零通道不吞掉同拍其他通道；
- `load = init || shift`，直接接 `kwt_acc28`；
- `valid = &v && (|e)`（m4 为 4 路、m8 为 8 路 `out_valid` 相与，且至少一个 enable）；
- `psum_out.data = {{4{acc[27]}}, acc}`，28 位补码和符号扩展回 32 位；
- ACC28 保持 `load > valid` 优先级，`sum_bits/carry_bits` 由压缩树给出。

## 3. 压缩树

均严格按 SPEC 连接，最终只有一棵树、一个 `kwt_acc28` CPA：

M=4：

```text
csa3(p0,p1,p2)   -> s0,c0
csa3(p3,s0,c0)   -> s1,c1
csa3(acc,s1,c1)  -> s2,c2
acc_next = s2 + c2
```

M=8：

```text
csa3(p0,p1,p2)   -> s0,c0
csa3(p3,p4,p5)   -> s1,c1
csa3(p6,p7,acc)  -> s2,c2
csa3(s0,c0,s1)   -> s3,c3
csa3(c1,s2,c2)   -> s4,c4
csa3(s3,c3,s4)   -> s5,c5
csa3(s5,c5,c4)   -> s6,c6
acc_next = s6 + c6
```

Yosys 统计可交叉验证规模：m4 得到 8 个 `$mul`（4 个 `kwt_mul` 各含低/高两段部分积）、
m8 得到 16 个 `$mul`，与 4/8 个乘法器一致。

## 4. 测试覆盖与参考模型

两个 TB 各自维护独立参考：每通道 3 拍 `longint` 乘积累加队列、3 拍 enable 队列、
3 拍 valid 队列；参考和只用 64 位整数做 `(exp_sum + Σen?p:0) & 0x0FFFFFFF`，
**没有复制 RTL 的 XOR/AND 压缩算法**。每个 posedge 后 `#1` 比较
`psum_out.data` 与 `{{4{exp_sum[27]}},exp_sum}`，覆盖装载、保持、累加全部节拍。

每 PE 的激励（775 拍）：

1. 复位 2 拍，检查输出为 0；
2. `init` 装入 `32'hF8000000`，检查低 28 位截取与符号扩展，再空拍保持；
3. 随机段 300 拍：随机 A/B、`n%11` 空拍、`n%9` 单路 A=0、`n%13` 单路 B=0、`n%17` 全零拍；
4. 零通道段 80 拍：每拍至少一路 A=0、另一路 B=0 轮换，另夹 `n%5` 全零拍；
5. 补码极值段 80 拍：A∈{-2048,2047,-1,1,0}、B∈{-512,511,-1,1,0} 组合，触发多次 28 位回绕；
6. 背靠背段 300 拍：`compute=1` 连续发射，检查无空拍连续累加；
7. 排空 3 拍后 `init` 装 `32'h81234567`，再 3 次 `shift` 装入不同值，每次后空拍检查保持。

## 5. 实际结果

运行命令（本目录内）：

```bash
cd .build/exp_mulwidth/ds_pe && ./run.sh
```

`run.log` 中实际输出：

```text
PE_PASS top=kwt_pe_m4 checks=775 valid_accs=700 zero_holds=32 loads=5 errors=0
PE_PASS top=kwt_pe_m8 checks=775 valid_accs=700 zero_holds=32 loads=5 errors=0
```

- 每个 PE 775 次逐拍输出比较，**700 次有效累加比较**（≥500 要求），
  32 次全零保持，5 次 `init/shift` 装载，错误数 **0**；
- Verilator 编译日志（`obj/*/compile.log`）无 warning，仿真退出码 0；
- `run.sh` 不只看退出码：还 grep `PE_PASS ... errors=0` 且禁止出现 `PE_FAIL`，
  最后打印 `ALL_OK`，本次脚本退出码为 0。

TB 灵敏度另用两份 /tmp 变异体验证（不在交付目录内，不改变交付 RTL）：

| 变异 | 结果 |
| --- | --- |
| m4 压缩树把 `p3` 换成 0 | `PE_FAIL ... errors=759`，首个错误在第 18 拍 |
| m8 去掉 `e[gi]` 零通道屏蔽 | `PE_FAIL ... errors=751`，首个错误在极值/零通道段 |

## 6. Yosys 结构检查

命令由 `run.sh` 生成，实际执行（`synth_check.log` 记录完整输出与 cell 统计）：

```bash
yosys -m slang -p "read_slang --top kwt_pe_m4_wrap \
  hardware/rtl/kwt_interfaces.sv hardware/rtl/kwt_mul.sv \
  hardware/versions/dual/rtl/kwt_acc28.sv \
  rtl/kwt_csa3.sv rtl/kwt_pe_m4.sv tb/kwt_pe_m4_wrap.sv; \
  hierarchy -check -top kwt_pe_m4_wrap; proc; opt; check -assert; stat"
```

（m8 同理。）结论：

- `read_slang`：`Build succeeded: 0 errors, 0 warnings`（两个顶层均为 0/0）；
- `hierarchy -check`：无缺失模块、无多驱动错误；
- `proc; opt; check -assert`：`Checking module ... Found and reported 0 problems`；
- cell 统计证明 PE 本体已被展开检查：m4 有 8 个 `$mul`、94 个 cell，
  m8 有 16 个 `$mul`、190 个 cell；
- 日志尾部为 `SYNTH_CHECK_PASS top=kwt_pe_m4_wrap` / `..._m8_wrap`，`run.sh` 退出码 0。

使用包装层的原因：Verilator 5.047 不支持把带 interface 端口的模块作为
`--top-module`，slang 也报 `top-level module has unconnected interface port`。
包装层实例化真实 `kwt_psum_if` 并连接真实的 `kwt_pe_m4/m8`，slang 会把接口端口
实例体就地展开，因此统计中的 8/16 个 `$mul` 即 PE 内的乘法器，检查对象仍是 PE 本体。
`kwt_csa3` 的 28 位压缩逻辑也在这两个 netlist 中（`$xor/$and/$or` cell）。

## 7. 已知限制

- 按 SPEC 未做 150MHz 综合/STA、未做标准单元面积与功耗；由主代理统一执行。
- 只验证单 PE 的算术与装载行为；`psum_in` 由 TB 直接驱动，不覆盖阵列级行链、
  A/B 供数压力、控制器的 `out_row` 等。
- 4/8 路共享同一 `compute`，因此 `out_valid` 天然对齐；TB 通过参考队列验证了
  有效/使能时序，但没有构造“不同乘法器 valid 错位”的故障注入（该场景在共享
  `compute` 的结构下不可达）。
- 参考模型用 64 位整数，乘积范围（|A×B| ≤ 2^20）与 8 路和（≤2^23）不会溢出；
  28 位回绕用掩码实现，和 RTL 的补码截断等价。
- `run.sh` 用固定随机种子（m4 `32'h2468ACE1`、m8 `32'h13579BDF`），
  结果可复现；换种子只需改 TB 初值。
- `obj/` 为生成物，可安全删除后由 `run.sh` 重建。
