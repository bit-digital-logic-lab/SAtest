// 结构检查包装：为m8 PE的kwt_psum_if端口实例化真实接口，仅暴露32位数据口。
// 仅用于Yosys read_slang层级检查；功能仿真直接实例化PE和接口。
module kwt_pe_m8_wrap (
    input logic clk,rst_n,
    input logic signed [11:0] a0,a1,a2,a3,a4,a5,a6,a7,
    input logic signed [9:0] b0,b1,b2,b3,b4,b5,b6,b7,
    input logic compute,init,shift,
    input logic [31:0] psum_in_data, // 上一行同列部分和
    output logic [31:0] psum_out_data // 本PE符号扩展后的部分和
);
    kwt_psum_if pin(),pout(); // 包装层唯一持有接口实例。
    assign pin.data=psum_in_data; // sink端只驱动data。
    kwt_pe_m8 u_pe(.clk(clk),.rst_n(rst_n),
        .a0(a0),.a1(a1),.a2(a2),.a3(a3),
        .a4(a4),.a5(a5),.a6(a6),.a7(a7),
        .b0(b0),.b1(b1),.b2(b2),.b3(b3),
        .b4(b4),.b5(b5),.b6(b6),.b7(b7),
        .compute(compute),.init(init),.shift(shift),
        .psum_in(pin),.psum_out(pout));
    assign psum_out_data=pout.data; // source端data引出。
endmodule
