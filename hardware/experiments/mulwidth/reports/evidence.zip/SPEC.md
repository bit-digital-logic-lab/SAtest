# 4/8 乘法器 PE 与 16×16 直接扩展实验规范

目的：在 55nm SS/1.08V/125°C、150MHz、同一 `kwt_mul` 下，比较
“每 PE 塞 4/8 个乘法器”与“直接扩大矩阵（16×16，每 PE 1 个乘法器）”的
标准单元面积、时序和供数压力。只做核心（PE 阵列）面积；A/B/C 存储另算。

## 边界

- 只允许改本目录 `.build/exp_mulwidth/ds_pe/` 或 `ds_arr16/`。
- 不改 `hardware/rtl/`、`hardware/versions/`、`model/`、`software/`。
- 不复制另一版本的同名模块；只编译自己目录 + 明确列出的公共 RTL。
- 参考实现：`hardware/versions/dual/rtl/`（双乘 PE/ACC28）、
  `hardware/rtl/kwt_mul.sv`、`hardware/rtl/kwt_interfaces.sv`。
- 只做 Verilator 功能/编译和 Yosys `read_slang` 结构检查；综合与时序由主代理统一跑。

## 公共约定

- A12：`signed [11:0]`，B10：`signed [9:0]`。
- 乘积：`kwt_mul` 的 `signed [21:0]`，三级流水，`out_valid/out_enable/product`。
- ACC28：`kwt_acc28` 的补码模 2^28 回绕；`load` 取 `load_data[27:0]`，
  输出 `{{4{acc[27]}},acc}` 符号扩展到 32 位。
- 零通道：`out_enable=0` 时该乘积按 0 参与压缩，不能丢掉同拍其他非零通道。
- 有效条件：所有乘法器 `out_valid` 对齐后为 1，且至少一个 `out_enable=1`；
  否则保持 ACC28。
- 压缩：3:2 压缩器 `kwt_csa3`（28 位）：
  `s=a^b^c; co=((a&b)|(a&c)|(b&c))<<1`。
- 最终：树输出 `(s,c)` 送入 `kwt_acc28` 的 `sum_bits/carry_bits`，
  由 `kwt_acc28` 做单拍 28 位 CPA。

## DS-1：4/8 乘 PE

目录：`.build/exp_mulwidth/ds_pe/`

接口（M=4/8 各自一个模块，端口同构）：

```systemverilog
module kwt_pe_m4 (
    input logic clk, rst_n,
    input logic signed [11:0] a0,a1,a2,a3,
    input logic signed [9:0]  b0,b1,b2,b3,
    input logic compute, init, shift,
    kwt_psum_if.sink psum_in,
    kwt_psum_if.source psum_out
);
```

M=8 同理加 a4..a7/b4..b7。

压缩树（必须按此结构，保证和主代理一致）：

M=4（输入 acc,p0,p1,p2,p3）：
```text
csa3(p0,p1,p2) -> s0,c0
csa3(p3,s0,c0) -> s1,c1
csa3(acc,s1,c1) -> s2,c2
acc_next = s2 + c2
```

M=8（输入 acc,p0..p7）：
```text
csa3(p0,p1,p2) -> s0,c0
csa3(p3,p4,p5) -> s1,c1
csa3(p6,p7,acc) -> s2,c2
csa3(s0,c0,s1) -> s3,c3
csa3(c1,s2,c2) -> s4,c4
csa3(s3,c3,s4) -> s5,c5
csa3(s5,c5,c4) -> s6,c6
acc_next = s6 + c6
```

- 乘积先 `{{6{product[21]}},product}` 扩展到 28 位，再按各自 enable 屏蔽为 0。
- `load = init || shift`；`valid = &v && (|e)`。
- `psum_out.data = {{4{acc[27]}},acc}`。

测试：
- 单 PE TB，随机 A/B、零通道、补码极值、连续背靠背、load/shift。
- 每个有效拍后等 3 拍，按独立 28 位模运算参考比较；至少 500 组。
- 用 Verilator 编译运行，日志存 `run.log`；不要只看退出码。
- 交付 `rtl/`、`tb/`、`run.sh`、`run.log`、`summary.md`（含端口、树、测试结果、Yosys read_slang 是否通过）。

## DS-2：16×16、每 PE 1 乘

目录：`.build/exp_mulwidth/ds_arr16/`

- `kwt_pe_m1`：一个 `kwt_mul` + `kwt_acc28`；`sum_bits=acc`、`carry_bits=p`
  （或等价的单拍 28 位 CPA），`load=init||shift`，输出符号扩展 32 位。
- `kwt_flat16`：16×16 =256 个 `kwt_pe_m1`，A 按行广播 `[16*12-1:0]`，
  B 按列广播 `[16*10-1:0]`，`valid` 统一，输出 `[256*32-1:0]`；
  `psum_in` 接 0，`init/shift` 接 0（只测计算核心面积）。
- TB：至少覆盖全零、单点非零、随机小矩阵；16×16×K8 与独立参考逐点比较。
- Verilator 编译运行，日志 `run.log`；Yosys `read_slang` 结构检查。
- 交付 `rtl/`、`tb/`、`run.sh`、`run.log`、`summary.md`。

## 主代理后续

- 用同一 `kwt_mul`/`kwt_acc28`/`kwt_csa3` 写扁平 8×8 的 M=1/2/4/8 与
  16×16 M=1/M=2 顶层，统一 Yosys+ABC 6666.667ps、OpenSTA 150MHz。
- 报告核心面积、每 256/512 MAC/拍面积、setup 余量、A/B 供数位宽；
  A/B/C 存储用相同 FF 风格另算，避免把核心面积和存储面积混在一起。
- 主代理独立复跑 DS 的测试，不直接采用 DS 的面积结论。
