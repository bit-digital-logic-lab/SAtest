#!/usr/bin/env python3
"""16 位输出量化精度：按输出列取 2 的幂 scale，算术右移+饱和，再解码比较 FP32。"""
import json, numpy as np
from pathlib import Path
ROOT=Path('/home/yang/Desktop/ic设计竞赛')
p=np.load(ROOT/'software/parameters.npz'); v=np.load(ROOT/'software/validation.npz')
out={'baseline_nrmse_percent':0.1433887135850633,'rows':[]}
for margin in (0,1):
    errs=[]; per=[]
    for L in range(1,13):
        k=f'layer{L:02d}'; sx=float(p[k+'_activation_scale']); sw=p[k+'_weight_scales']
        w=p[k+'_weight'].astype(np.int64); b=p[k+'_bias'].astype(np.int64)
        ys=[]; refs=[]
        for s in range(2):
            a=np.clip(np.rint(v[k+'_x'][s]/sx),-2047,2047).astype(np.int64)
            ys.append(a@w+b); refs.append(v[k+'_fp32'][s])
        mx=np.max([np.max(np.abs(y),axis=0) for y in ys],axis=0)
        se=np.where(mx>32767,np.ceil(np.log2(np.maximum(mx,1)/32767)).astype(int),0)+margin
        scale=np.exp2(se).astype(np.int64)
        le=[]
        for y,ref in zip(ys,refs):
            q=np.clip(np.rint(y/scale),-32768,32767).astype(np.int64)
            outv=q.astype(np.float64)*scale*sx*sw
            le.append(100*np.linalg.norm(outv-ref)/np.linalg.norm(ref))
        errs+=le; per.append(max(le))
    out['rows'].append({'margin_bits':margin,'max_nrmse_percent':max(errs),
        'mean_nrmse_percent':float(np.mean(errs)),'worst_layer':int(np.argmax(per)+1),
        'per_layer_max_percent':[float(x) for x in per]})
Path(ROOT/'.build/exp_mulwidth/requant/accuracy.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
