from pathlib import Path
import json,re,subprocess,sys
ROOT=Path('/home/yang/Desktop/ic设计竞赛'); D=ROOT/'.build/exp_mulwidth/requant'
LIB=Path('/home/yang/yosys-sta/pdk/icsprout55/IP/STD_cell/ics55_LLSC_H7C_V1p10C100/ics55_LLSC_H7CL/liberty/ics55_LLSC_H7CL_ss_rcworst_1p08_125_nldm.lib')
STA=Path(ROOT/'.build/tools/opensta/usr/bin/sta')
src=[D/'rtl/kwt_requant8.sv',D/'rtl/requant8_reg.sv']
(D/'synth.ys').write_text(f'''read_slang --top requant8_reg {' '.join(map(str,src))}
synth -top requant8_reg -flatten -noabc
dfflibmap -liberty {LIB}
abc -liberty {LIB} -D 6666.667
clean
hilomap -singleton -hicell TIEHIH7L Z -locell TIELOH7L Z
setundef -zero
clean
read_liberty -lib {LIB}
check -mapped -assert
tee -o {D/'stat.json'} stat -json -liberty {LIB}
write_json {D/'netlist.json'}
''')
subprocess.run(['yosys','-Q','-T','-m','slang','-s',str(D/'synth.ys')],cwd=D,check=True,stdout=(D/'synth.log').open('w'),stderr=subprocess.STDOUT)
sys.path.insert(0,str(ROOT/'hardware')); import synth as flow
m=json.loads((D/'netlist.json').read_text())['modules']['requant8_reg']
ports=flow.scalar_netlist(m,'requant8_reg',D/'netlist.v')
inputs=[n for n,d in ports if d=='input' and n!='clk']; outputs=[n for n,d in ports if d=='output']
sdc='create_clock -name clk -period 6.666667 [get_ports clk]\nset_clock_uncertainty 0.1 [get_clocks clk]\n'
for p in inputs: sdc+=f'set_input_delay 0.5 -clock clk [get_ports {{{p}}}]\nset_input_transition 0.1 [get_ports {{{p}}}]\n'
for p in outputs: sdc+=f'set_output_delay 0.5 -clock clk [get_ports {{{p}}}]\nset_load 0.01 [get_ports {{{p}}}]\n'
(D/'design.sdc').write_text(sdc)
(D/'opensta.tcl').write_text(f'''read_liberty {LIB}
read_verilog netlist.v
link_design requant8_reg
read_sdc design.sdc
set_clock_transition 0.1 [get_clocks clk]
report_worst_slack -digits 6 > slack.rpt
report_tns -digits 6 > tns.rpt
report_checks -path_delay max -group_count 1 -digits 6 > critical.rpt
exit
''')
subprocess.run([str(STA),'-exit','opensta.tcl'],cwd=D,check=True,stdout=(D/'opensta.log').open('w'),stderr=subprocess.STDOUT)
stat=json.loads((D/'stat.json').read_text())['modules']['\\requant8_reg']
slack=float(re.search(r'worst slack\s+([+\-\d.eE]+)',(D/'slack.rpt').read_text()).group(1))
tns=float(re.search(r'tns\s+([+\-\d.eE]+)',(D/'tns.rpt').read_text()).group(1))
out={'top':'requant8_reg','area_um2':stat['area'],'cells':stat['num_cells'],'setup_slack_ns':slack,'tns_ns':tns}
(D/'result.json').write_text(json.dumps(out,indent=2)+'\n'); print(out)
