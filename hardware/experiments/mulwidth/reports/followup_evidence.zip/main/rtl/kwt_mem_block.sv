// 实验用 32×32 块存储+读口模型：A/B/C 触发器阵列，读口数随 ROWS/COLS/LANES 变化。
// 只用于面积对照；不含主机控制、状态机、地址生成和 C 行移位。
module kwt_mem_block #(
    parameter int ROWS=8,
    parameter int COLS=8,
    parameter int LANES=1
) (
    input logic clk,
    input logic a_we, input logic [9:0] a_addr, input logic [11:0] a_wdata,
    input logic b_we, input logic [10:0] b_addr, input logic [9:0] b_wdata,
    input logic c_we, input logic [9:0] c_addr, input logic [31:0] c_wdata,
    input logic [5:0] a_k, input logic [5:0] b_k, // 当前 K 起点，LANES 个相邻 K
    output logic [ROWS*LANES*12-1:0] a_rows,
    output logic [COLS*LANES*10-1:0] b_cols,
    output logic [31:0] c_rdata
);
    localparam int AD=ROWS*64;      // A 行优先，每行 64 个 K
    localparam int BD=COLS*64;      // B 列优先，每列 64 个 K
    logic [11:0] a_mem[0:AD-1];
    logic [9:0]  b_mem[0:BD-1];
    logic [31:0] c_mem[0:1023];
    // 单写口；读口由阵列规模决定，组合读出。
    always_ff @(posedge clk) begin
        if (a_we) a_mem[a_addr[9:0]] <= a_wdata;
        if (b_we) b_mem[b_addr[10:0]] <= b_wdata;
        if (c_we) c_mem[c_addr] <= c_wdata;
    end
    // A/B 组合读，再打一拍；对应现有块中“存储读→乘法器输入寄存器”的一拍。
    logic [ROWS*LANES*12-1:0] a_rows_c;
    logic [COLS*LANES*10-1:0] b_cols_c;
    logic [31:0] c_rdata_c;
    for (genvar r=0;r<ROWS;r++) begin : arows
        for (genvar m=0;m<LANES;m++) begin : alane
            assign a_rows_c[(r*LANES+m)*12+:12] =
                a_mem[r*64 + a_k*LANES + m];
        end
    end
    for (genvar c=0;c<COLS;c++) begin : bcols
        for (genvar m=0;m<LANES;m++) begin : blane
            assign b_cols_c[(c*LANES+m)*10+:10] =
                b_mem[c*64 + b_k*LANES + m];
        end
    end
    assign c_rdata_c=c_mem[c_addr];
    always_ff @(posedge clk) begin
        a_rows<=a_rows_c; b_cols<=b_cols_c; c_rdata<=c_rdata_c;
    end
endmodule

module kwt_mem_8_m1(input logic clk,
    input logic a_we,input logic [9:0] a_addr,input logic [11:0] a_wdata,
    input logic b_we,input logic [10:0] b_addr,input logic [9:0] b_wdata,
    input logic c_we,input logic [9:0] c_addr,input logic [31:0] c_wdata,
    input logic [5:0] a_k,input logic [5:0] b_k,
    output logic [95:0] a_rows,output logic [79:0] b_cols,output logic [31:0] c_rdata);
    kwt_mem_block #(.ROWS(8),.COLS(8),.LANES(1)) u(.clk(clk),
        .a_we(a_we),.a_addr(a_addr),.a_wdata(a_wdata),
        .b_we(b_we),.b_addr(b_addr),.b_wdata(b_wdata),
        .c_we(c_we),.c_addr(c_addr),.c_wdata(c_wdata),.a_k(a_k),.b_k(b_k),
        .a_rows(a_rows),.b_cols(b_cols),.c_rdata(c_rdata));
endmodule

module kwt_mem_8_m4(input logic clk,
    input logic a_we,input logic [9:0] a_addr,input logic [11:0] a_wdata,
    input logic b_we,input logic [10:0] b_addr,input logic [9:0] b_wdata,
    input logic c_we,input logic [9:0] c_addr,input logic [31:0] c_wdata,
    input logic [5:0] a_k,input logic [5:0] b_k,
    output logic [383:0] a_rows,output logic [319:0] b_cols,output logic [31:0] c_rdata);
    kwt_mem_block #(.ROWS(8),.COLS(8),.LANES(4)) u(.clk(clk),
        .a_we(a_we),.a_addr(a_addr),.a_wdata(a_wdata),
        .b_we(b_we),.b_addr(b_addr),.b_wdata(b_wdata),
        .c_we(c_we),.c_addr(c_addr),.c_wdata(c_wdata),.a_k(a_k),.b_k(b_k),
        .a_rows(a_rows),.b_cols(b_cols),.c_rdata(c_rdata));
endmodule

module kwt_mem_16_m1(input logic clk,
    input logic a_we,input logic [9:0] a_addr,input logic [11:0] a_wdata,
    input logic b_we,input logic [10:0] b_addr,input logic [9:0] b_wdata,
    input logic c_we,input logic [9:0] c_addr,input logic [31:0] c_wdata,
    input logic [5:0] a_k,input logic [5:0] b_k,
    output logic [191:0] a_rows,output logic [159:0] b_cols,output logic [31:0] c_rdata);
    kwt_mem_block #(.ROWS(16),.COLS(16),.LANES(1)) u(.clk(clk),
        .a_we(a_we),.a_addr(a_addr),.a_wdata(a_wdata),
        .b_we(b_we),.b_addr(b_addr),.b_wdata(b_wdata),
        .c_we(c_we),.c_addr(c_addr),.c_wdata(c_wdata),.a_k(a_k),.b_k(b_k),
        .a_rows(a_rows),.b_cols(b_cols),.c_rdata(c_rdata));
endmodule

module kwt_mem_16x32_m1(input logic clk,
    input logic a_we,input logic [9:0] a_addr,input logic [11:0] a_wdata,
    input logic b_we,input logic [10:0] b_addr,input logic [9:0] b_wdata,
    input logic c_we,input logic [9:0] c_addr,input logic [31:0] c_wdata,
    input logic [5:0] a_k,input logic [5:0] b_k,
    output logic [191:0] a_rows,output logic [319:0] b_cols,output logic [31:0] c_rdata);
    kwt_mem_block #(.ROWS(16),.COLS(32),.LANES(1)) u(.clk(clk),
        .a_we(a_we),.a_addr(a_addr),.a_wdata(a_wdata),
        .b_we(b_we),.b_addr(b_addr),.b_wdata(b_wdata),
        .c_we(c_we),.c_addr(c_addr),.c_wdata(c_wdata),.a_k(a_k),.b_k(b_k),
        .a_rows(a_rows),.b_cols(b_cols),.c_rdata(c_rdata));
endmodule
