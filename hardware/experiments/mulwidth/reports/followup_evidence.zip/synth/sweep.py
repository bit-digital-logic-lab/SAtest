#!/usr/bin/env python3
"""对已映射的 mulwidth 核心网表做真实 OpenSTA 频率扫描（只读网表，不重映射）。"""
from pathlib import Path
import json, re, subprocess, sys
ROOT=Path('/home/yang/Desktop/ic设计竞赛')
OUT=ROOT/'.build/exp_mulwidth/synth'
LIB=Path('/home/yang/yosys-sta/pdk/icsprout55/IP/STD_cell/ics55_LLSC_H7C_V1p10C100/ics55_LLSC_H7CL/liberty/ics55_LLSC_H7CL_ss_rcworst_1p08_125_nldm.lib')
STA=Path(ROOT/'.build/tools/opensta/usr/bin/sta')
FREQS=[150,175,200,225,250]
TOPS=['kwt_core_8_m2','kwt_core_8_m4','kwt_core_8_m8','kwt_core_16_m1','kwt_core_16x32_m1']
for top in TOPS:
    d=OUT/top
    sdc=(d/'design.sdc').read_text()
    lines=[f'read_liberty {LIB}','read_verilog netlist.v',f'link_design {top}']
    for mhz in FREQS:
        label=f'{mhz}'
        one=re.sub(r'create_clock -name clk -period [\d.]+',f'create_clock -name clk -period {1000/mhz:.9f}',sdc)
        one+='set_clock_transition 0.1 [get_clocks clk]\n'
        (d/f'{label}.sdc').write_text(one)
        lines.append(f'read_sdc {label}.sdc')
        lines.append(f'report_worst_slack -digits 6 > {label}_slack.rpt')
        lines.append(f'report_tns -digits 6 > {label}_tns.rpt')
    (d/'sweep.tcl').write_text('\n'.join(lines)+'\nexit\n')
    subprocess.run([str(STA),'-exit','sweep.tcl'],cwd=d,check=True,
                   stdout=(d/'sweep.log').open('w'),stderr=subprocess.STDOUT)
    rows=[]
    for mhz in FREQS:
        slack=float(re.search(r'worst slack\s+([+\-\d.eE]+)',(d/f'{mhz}_slack.rpt').read_text()).group(1))
        tns=float(re.search(r'tns\s+([+\-\d.eE]+)',(d/f'{mhz}_tns.rpt').read_text()).group(1))
        rows.append({'frequency_mhz':mhz,'setup_slack_ns':slack,'tns_ns':tns,'pass':slack>=0 and tns==0})
    (d/'sweep_results.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(top, rows, flush=True)
