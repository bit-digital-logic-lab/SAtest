from pathlib import Path
import json,re,subprocess,sys,time
ROOT=Path('/home/yang/Desktop/ic设计竞赛'); D=ROOT/'.build/exp_mulwidth/synth'
LIB=Path('/home/yang/yosys-sta/pdk/icsprout55/IP/STD_cell/ics55_LLSC_H7C_V1p10C100/ics55_LLSC_H7CL/liberty/ics55_LLSC_H7CL_ss_rcworst_1p08_125_nldm.lib')
STA=Path(ROOT/'.build/tools/opensta/usr/bin/sta')
sys.path.insert(0,str(ROOT/'hardware')); import synth as flow
src=ROOT/'.build/exp_mulwidth/main/rtl/kwt_mem_block.sv'
tops=['kwt_mem_8_m1','kwt_mem_8_m4','kwt_mem_16_m1','kwt_mem_16x32_m1']
rows=[]
for top in tops:
    d=D/top; d.mkdir(parents=True,exist_ok=True)
    (d/'synth.ys').write_text(f'''read_slang --top {top} {src}
synth -top {top} -flatten -noabc
dfflibmap -liberty {LIB}
abc -liberty {LIB} -D 6666.667
clean
hilomap -singleton -hicell TIEHIH7L Z -locell TIELOH7L Z
setundef -zero
clean
read_liberty -lib {LIB}
check -mapped -assert
tee -o {d/'stat.json'} stat -json -liberty {LIB}
write_json {d/'netlist.json'}
''')
    subprocess.run(['yosys','-Q','-T','-m','slang','-s',str(d/'synth.ys')],cwd=d,check=True,
                   stdout=(d/'synth.log').open('w'),stderr=subprocess.STDOUT)
    m=json.loads((d/'netlist.json').read_text())['modules'][top]
    ports=flow.scalar_netlist(m,top,d/'netlist.v')
    ins=[n for n,drc in ports if drc=='input' and n!='clk']; outs=[n for n,drc in ports if drc=='output']
    sdc='create_clock -name clk -period 6.666667 [get_ports clk]\nset_clock_uncertainty 0.1 [get_clocks clk]\n'
    for p in ins: sdc+=f'set_input_delay 0.5 -clock clk [get_ports {{{p}}}]\nset_input_transition 0.1 [get_ports {{{p}}}]\n'
    for p in outs: sdc+=f'set_output_delay 0.5 -clock clk [get_ports {{{p}}}]\nset_load 0.01 [get_ports {{{p}}}]\n'
    (d/'design.sdc').write_text(sdc)
    (d/'opensta.tcl').write_text(f'''read_liberty {LIB}
read_verilog netlist.v
link_design {top}
read_sdc design.sdc
set_clock_transition 0.1 [get_clocks clk]
report_worst_slack -digits 6 > slack.rpt
report_tns -digits 6 > tns.rpt
exit
''')
    subprocess.run([str(STA),'-exit','opensta.tcl'],cwd=d,check=True,stdout=(d/'opensta.log').open('w'),stderr=subprocess.STDOUT)
    stat=json.loads((d/'stat.json').read_text())['modules']['\\'+top]
    slack=float(re.search(r'worst slack\s+([+\-\d.eE]+)',(d/'slack.rpt').read_text()).group(1))
    rows.append({'top':top,'area_um2':stat['area'],'cells':stat['num_cells'],'setup_slack_ns':slack})
    print(rows[-1],flush=True)
(D/'mem_results.json').write_text(json.dumps(rows,indent=2)+'\n')
