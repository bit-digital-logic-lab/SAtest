read_liberty /home/yang/yosys-sta/pdk/icsprout55/IP/STD_cell/ics55_LLSC_H7C_V1p10C100/ics55_LLSC_H7CL/liberty/ics55_LLSC_H7CL_ss_rcworst_1p08_125_nldm.lib
read_verilog netlist.v
link_design kwt_core_synth
read_sdc design.sdc
set_clock_transition 0.1 [get_clocks clk]
check_setup -verbose > coverage.rpt
report_worst_slack -digits 6 > slack.rpt
report_tns -digits 6 > tns.rpt
report_checks -path_delay max -group_count 1 -fields {capacitance slew} -digits 6 > critical.rpt
set_power_activity -global -activity 0.1 -duty 0.5
report_power -digits 6 > power_0p1.rpt
set_power_activity -global -activity 0.5 -duty 0.5
report_power -digits 6 > power_0p5.rpt
exit
