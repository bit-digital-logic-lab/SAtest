read_liberty /home/yang/yosys-sta/pdk/icsprout55/IP/STD_cell/ics55_LLSC_H7C_V1p10C100/ics55_LLSC_H7CL/liberty/ics55_LLSC_H7CL_ss_rcworst_1p08_125_nldm.lib
read_verilog netlist.v
link_design kwt_core_synth
read_sdc 150.sdc
check_setup -verbose > 150_coverage.rpt
report_worst_slack -digits 6 > 150_slack.rpt
report_tns -digits 6 > 150_tns.rpt
report_checks -path_delay max -group_count 1 -fields {capacitance slew} -digits 6 > 150_timing.rpt
read_sdc 200.sdc
check_setup -verbose > 200_coverage.rpt
report_worst_slack -digits 6 > 200_slack.rpt
report_tns -digits 6 > 200_tns.rpt
report_checks -path_delay max -group_count 1 -fields {capacitance slew} -digits 6 > 200_timing.rpt
read_sdc 250.sdc
check_setup -verbose > 250_coverage.rpt
report_worst_slack -digits 6 > 250_slack.rpt
report_tns -digits 6 > 250_tns.rpt
report_checks -path_delay max -group_count 1 -fields {capacitance slew} -digits 6 > 250_timing.rpt
read_sdc 300.sdc
check_setup -verbose > 300_coverage.rpt
report_worst_slack -digits 6 > 300_slack.rpt
report_tns -digits 6 > 300_tns.rpt
report_checks -path_delay max -group_count 1 -fields {capacitance slew} -digits 6 > 300_timing.rpt
read_sdc 350.sdc
check_setup -verbose > 350_coverage.rpt
report_worst_slack -digits 6 > 350_slack.rpt
report_tns -digits 6 > 350_tns.rpt
report_checks -path_delay max -group_count 1 -fields {capacitance slew} -digits 6 > 350_timing.rpt
read_sdc 352.sdc
check_setup -verbose > 352_coverage.rpt
report_worst_slack -digits 6 > 352_slack.rpt
report_tns -digits 6 > 352_tns.rpt
report_checks -path_delay max -group_count 1 -fields {capacitance slew} -digits 6 > 352_timing.rpt
read_sdc 353.sdc
check_setup -verbose > 353_coverage.rpt
report_worst_slack -digits 6 > 353_slack.rpt
report_tns -digits 6 > 353_tns.rpt
report_checks -path_delay max -group_count 1 -fields {capacitance slew} -digits 6 > 353_timing.rpt
read_sdc 400.sdc
check_setup -verbose > 400_coverage.rpt
report_worst_slack -digits 6 > 400_slack.rpt
report_tns -digits 6 > 400_tns.rpt
report_checks -path_delay max -group_count 1 -fields {capacitance slew} -digits 6 > 400_timing.rpt
exit
